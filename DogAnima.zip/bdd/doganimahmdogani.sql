-- phpMyAdmin SQL Dump
-- version 4.4.13.1
-- http://www.phpmyadmin.net
--
-- Client :  doganimahmdogani.mysql.db
-- Généré le :  Jeu 26 Mai 2016 à 15:04
-- Version du serveur :  5.5.47-0+deb7u1-log
-- Version de PHP :  5.4.45-0+deb7u2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `doganimahmdogani`
--

-- --------------------------------------------------------

--
-- Structure de la table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `content_id` int(255) NOT NULL,
  `content_login` varchar(10) NOT NULL,
  `content_name` varchar(20) NOT NULL,
  `content_title` varchar(50) NOT NULL,
  `content_text1` mediumtext NOT NULL,
  `content_text2` mediumtext NOT NULL,
  `content_text3` mediumtext NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `content`
--

INSERT INTO `content` (`content_id`, `content_login`, `content_name`, `content_title`, `content_text1`, `content_text2`, `content_text3`) VALUES
(1, 'Laurent', 'index.php', 'Garde de chiens (dog sitting) en Indre-et-Loire', '<strong>Spécialistes des chiens</strong>, nous savons qu''ils ont tous leur caractère propre  et que l''affection qu''on leur prodigue est essentielle en l''absence de leurs maîtres. \r\n<a class="alink" href="contact.php" title="Contact DogAnima">DogAnima</a> propose différentes formules de gardiennage personnalisées, de véritables solutions alternatives aux pensions ou aux chenils impersonnels.', '<h2>La garde de chien en famille d’accueil</h2>\r\n<p>Cette prestation est particulièrement recommandée en cas d''absence prolongée ou si votre chien à l''habitude d''évoluer au sein d''un environnement affectif très présent en journée (personnes au foyer, enfants).</p>\r\n<p>Le jour de votre départ en vacances, vous confiez votre compagnon à l''une de nos <a class="alink" href="tarifs.php"  title="dog sitting en famille d''accueil"><strong>familles d’accueil pour chiens</strong></a> qui saura lui apporter toute l’attention dont il aura besoin.</p>\r\n<p>Ce mode de garde est idéal pour les chiens très sociabilisés qui n''aiment pas la solitude et qui ont besoin de nombreuses interactions au quotidien avec les humains.</p>\r\n<p>Afin de faciliter l''accueil de votre animal dans sa <strong>famille d''accueil</strong>, vous aurez à coeur de communiquer ses habitudes spécifiques.</p> \r\n', '<h2>La garde de chien au domicile</h2>\r\n<p>Cette solution de garde est plutôt destinée aux absences de courtes durées, si votre chien à l''habitude de rester seul en journée, ou s''il est très attaché à son lieu de vie.</p>\r\n<p>Pendant la journée le <a class="alink" href="tarifs.php" title="dog sitter à domicile"><strong>dog sitter</strong></a> est libre de ses occupations. Le soir au lieu de rentrer à son domicile, il se rend chez vous pour retrouver votre compagnon et s''occuper de lui jusqu’à votre retour, voir de passer la nuit à votre domicile pour le nourrir et le sortir le lendemain matin avant de partir à son travail.</p>\r\n<p>Attention : la garde à domicile n''est pas du home sitting. Les tâches ménagères ne font pas partie des missions de nos <strong>pet sitters</strong>. Leur unique mission est de s''occuper du bien-être de votre chien jusqu''à votre retour : nourriture, eau, promenades, jeux, câlins, etc.</p>'),
(2, 'Emmanuel', 'presentation.php', 'Au service des propriétaires de chiens', '', '<h2>Une association de spécialistes canins</h2>\r\n<p>A l''approche des beaux jours la <strong>garde de chien</strong> est souvent un problème pour les propriétaires qui partent en vacances.</p>\r\n<p>Les pensions canines traditionnelles n''offrent pas toujours un service à la hauteur des attentes de leurs maîtres et sont souvent surchargées, particulièrement l''été.</p>\r\n<p>C''est en partant du constat que cette situation favorisait les abandons et la détresse des chiens que l''association <a class="alink" href="contact.php"  title="Contacter DogAnima"><strong>DogAnima</strong></a> a vu le jour début 2015 en Touraine.</p>\r\n<p>Présente sur toute l''Indre-et-Loire, DogAnima est une association dédiée à la <strong>garde de chien en familles d''accueil</strong> et de <strong>dog sitters à domicile</strong>. DogAnima propose un vaste réseau de personnes aimantes des chiens et prêtes à les acueillir. <a class="alink" href="tarifs.php"  title="Intervenants DogAnima">Nos dog sitters</a> on tous une expérience confirmée dans le gardiennage de chiens.</p>', '<h2>Une garde personnalisée pour votre compagnon</h2>\r\n<p>Nos familles d''accueil et nos nounous à domicile permettent à vos chiens de rester dans un cadre familial, entourés d''affection. Les chiens sont chouchoutés et considérés, en accueil, comme un nouveau membre de la famille. Ils bénéficient d''une attention toute particulière, \r\nsemblable à celle que vous pouvez leur apporter.</p>');

-- --------------------------------------------------------

--
-- Structure de la table `msge`
--

CREATE TABLE IF NOT EXISTS `msge` (
  `msge_id` int(5) NOT NULL,
  `msge_subj` varchar(30) NOT NULL,
  `msge_txt` varchar(255) NOT NULL,
  `msge_ema` varchar(30) NOT NULL DEFAULT 'l.gouthiere@gmail.com'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `msge`
--

INSERT INTO `msge` (`msge_id`, `msge_subj`, `msge_txt`, `msge_ema`) VALUES
(1, 'Demande de contact', 'Je serais intÃ©ressÃ© par une garde Ã  domicile.', 'l.gouthiere@gmail.com'),
(2, 'Demande d''information', 'Int&eacute;ress&eacute; pour garder une meute.', 'f.hilmo@juste.com');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user` int(4) NOT NULL,
  `user_login` varchar(10) NOT NULL,
  `user_password` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`user`, `user_login`, `user_password`) VALUES
(1, 'Emmanuel', 'ELDog2016!'),
(2, 'Laurent', 'LGDog2016!'),
(3, 'Philippe', 'Phil-2016');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`content_id`);

--
-- Index pour la table `msge`
--
ALTER TABLE `msge`
  ADD PRIMARY KEY (`msge_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user`),
  ADD UNIQUE KEY `user_login` (`user_login`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `content`
--
ALTER TABLE `content`
  MODIFY `content_id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `msge`
--
ALTER TABLE `msge`
  MODIFY `msge_id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `user` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
