<!DOCTYPE html>
<!-- Projet DogAnima            
     actionprespage.php                
     Création 14/04/2016        
	 MAJ du 14/04/2016     
     MAJ du 22/04/2016	 
	 MAJ du 23/04/2016	
	 MAJ du 24/04/2016	
	 But : Insérer les textes modifiés de presentation.php
-->
<html>
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
-->
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
<meta name="description" content="Garde de chiens en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Garde de chiens à domicile ou en accueil</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>

<?php
// Inclusion des constantes de connexion (Attention ce ne sont pas les même que sur le serveur web de OVH)
include("inc/connect.inc.php");

$c_name = 'presentation.php';
$login = $_COOKIE['firstname'];
$c_title = addslashes($_POST['ititle']);
$c_text1 = addslashes($_POST['itext1']);
$c_text21 = addslashes($_POST['itext21']);
$c_text22 = addslashes($_POST['itext22']);

// Insertion à la suite du contenu de la page index.php modifiée
if ($id = mysqli_connect($dbhost, $dbuser, $dbpassw)) {
   mysqli_query($id, "SET NAMES 'utf8'");
   if (mysqli_select_db($id, $dbname)){
	  $request = "INSERT INTO content (content_name, content_login, content_title, content_text1, content_text2, content_text3) VALUES ('$c_name', '$login', '$c_title', '$c_text1', '$c_text21', '$c_text22')";
	  mysqli_query($id, $request); 
      // Attention le commit est indispensable: sinon il ne met pas à jour la table.
	  mysqli_query($id, 'COMMIT');
   } else {	 
       mysqli_close($id); 
	   header("Location: ./choice2.php?urdel=32250rop212"); 
   }
   mysqli_close($id);     
} else {
	 header("Location: ./choice2.php?urdel=32250rop212"); 
}   

// Retour à la page de choix de page à modifier 
   header("Location: ./choice2.php?urdel=32250rop212"); 
?>

</body>
</html>