﻿<?php
include("inc/connect.inc.php");

$login = $_POST['login']; 
$password = $_POST['password']; 

// (1, 'Emmanuel', 'ELDog2016!'),
// (2, 'Laurent', 'LGDog2016!'),
// (3, 'Philippe', 'Phil-2016');

if ($id = mysqli_connect($dbhost, $dbuser, $dbpassw)){
  if (mysqli_select_db($id, $dbname)){ 
	 $request = "select user_login, user_password from user";  
     if ($result = mysqli_query($id, $request)){
        while ($ligne = mysqli_fetch_row($result)){
      	   if (($login == $ligne[0]) && ($password == $ligne[1])) {
		       $OK = 1;
		       //print($ligne[0]."\n");
		       //print($ligne[1]);
			   $expire = 365*24*3600;
               setcookie("firstname", $login, time() + $expire);
			   setcookie("BY", 1, time() + $expire);
			   header("Location: ./choice1.php?gjklp=12269jkl309");
      	   }   
		}		     		
       	if (!$OK) {	
	       mysqli_close($id);   
           header("Location: ./connexion.php?gzhty=268hz3622jo");		   
		}
		mysqli_close($id);     
     } 
   } else {
        mysqli_close($id);  		
   }		
} 

?>
