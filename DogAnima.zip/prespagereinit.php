<!DOCTYPE html>
<!-- Projet DogAnima            
     prespagereinit.php                
	 Création : 25/04/2016
	 But: Réinitialiser le texte de presentation.php avec le texte d'origine
-->
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
-->
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
<meta name="description" content="Garde de chiens en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Garde de chiens à domicile ou en accueil</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<?php include ("inc/headermodifypage.inc.php"); ?>
<h1>
<?php 
    if (isset($_GET["tubuz"])) { 
	   $tp = $_GET["tubuz"];
       if ($tp != "56620uif156156") {
           header("Location: ./choice2.php?urdel=32250rop212");
	   }
	}   
?>
</h1>
<p></p>

<?php
// Inclusion des constantes de connexion
include("inc/connect.inc.php");

// On va ici rechercher le texte de la page presentation.php enregistrée dans la base de données
if ($id = mysqli_connect($dbhost, $dbuser, $dbpassw)){
  mysqli_query($id, "SET NAMES 'utf8'");	
  if (mysqli_select_db($id, $dbname)) { 
	 $request = "select content_title, content_text1, content_text2, content_text3 from content where content_id ='2' and trim(content_name) = 'presentation.php'";
     if ($result = mysqli_query($id, $request)){
        while ($ligne = mysqli_fetch_row($result)){
		   $title = $ligne[0];
		   $text1 = $ligne[1];
		   $text21 = $ligne[2];
		   $text22 = $ligne[3];
		}		     		
	    mysqli_close($id);   	   
     } else {
          mysqli_close($id);    
          header("Location: ./choice2.php?urdel=32250rop212");	
     }		  
  } else {
       mysqli_close($id);     
	   header("Location: ./choice2.php?urdel=32250rop212");
  }	   
} else {
     mysqli_close($id);     
	 header("Location: ./choice2.php?urdel=32250rop212");
}	 
?>

<!-- On procéde à l'affichage des différents champs en vue d'éventuellement les modifier -->
<form action="actionprespage.php" method="post" enctype="multipart/form-data" name="form">
<div class="index1">
<p></p>
<br />

<!-- Formulaire de visualisation puis de modification -->
<div class="center">
<input type="text" name="ititle" size="75" maxlength="100" readonly="readonly" value="<?php print($title); ?>">
</div>
<p></p>
<!-- Attention la limite à 375 a été vérifiée -->
<div class="center">
<textarea name="itext1" rows="6" cols="95" maxlength="375" readonly="readonly"><?php print($text1); ?></textarea>
</div>
<p></p>
<!-- Attention la limite à 1000 a été vérifiée -->
<table style="width: 100%;">
<tr>
<td style="width: 49%;">
<textarea rows="19" name="itext21" cols="55" maxlength="1150" readonly="readonly"><?php print($text21); ?></textarea>
</td>
<td>&nbsp;</td>
<!-- Attention la limite à 1000 a été vérifiée -->
<td style="width: 49%;">
<textarea rows="19" name="itext22" cols="55" maxlength="600" readonly="readonly"><?php print($text22); ?></textarea>
</td>
</tr>
</table>
<div class="right">
<!-- Sauvegarder la page modifiée (texte d'origine) -->
<input type="submit" style="color: #00F;" value="Sauvegarder" />
&nbsp;
<!-- Retour au menu choice2 -->
<a href="choice2.php?urdel=32250rop212"><input type="button" style="color: red;" value="Quitter"></a>
&nbsp;
</div>
<br />
</div>
</form>
<p>&nbsp;</p>

<!-- Intégration du pied de page -->
<?php include("inc/footer.inc.php"); ?>
</body>
</html>