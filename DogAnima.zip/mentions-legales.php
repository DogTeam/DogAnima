<!DOCTYPE html>
<!-- Projet DogAnima            
     mentionsleg.html                 
     MAJ du 13/11/2015       
	 MAJ du 12/01/2015       
     Rem : Tout navigateur      
-->
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Mentions légales</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<?php include ("inc/header.inc.php"); ?>
<p></p>
<h1>Mentions légales</h1>
<div class="c9">
<div class="justify">
L'association DogAnima est fictive.<br /><br />
Les intervenants sont fictifs.<br /><br />
La localisation et les coordonnées sont fictives.<br /><br />
Les images, les photos sont libres de droits <a href="http://francais.istockphoto.com/photo title="isStockPhoto" target="_blank">iStockphoto </a>,&nbsp;
<a href="http://www.Pixabay.com" title="Pixabay.com" target="_blank">Pixabay.com</a> où achetées sur Adobe Stock.
<br /><br />
Ce site reste et restera vraisemblablement fictif et est un exercice projet, sans but de concurrence de site existant ou ressemblant.

<div><p><strong>doganima.org est un service éditée par l'association DogAnima :</strong> dont le siège social est situé à :<br />
Château de la Villaine<br />
La Faisanerie<br />
37320 Esvres<br />
</p>
<p><strong>Directeur de la publication</strong>:<br />
<strong>Laurent GOUTHIERE</strong></p>
<p><strong>Agrément :</strong><br />
L'association DogAnigma est <strong>déclarée </strong>sous le numéro N°SAP789547878.<br />
</p>
<p><strong>Hébergeur :</strong><br />
OVH<br />
2 rue Kellermann<br />
59100 Roubaix<br />
France</p>
<p><strong>Droits d’auteurs :</strong><br />
Le site est protégé par le droit d’auteur. Les droits de propriété intellectuelle relatifs au site restent la propriété exclusive de domestiquerletemps.com. Les marques de l’éditeur du site et de ses partenaires, ainsi que les logos figurant sur le site sont des marques déposées. L’utilisation de ce site ne vous confère aucun droit. En conséquence, vous ne pouvez télécharger tout ou partie des textes, images, sons, photographies, données, marques et tout autre élément qui y sont contenus qu’aux fins prévues à l’article L 122-5 du code de la propriété intellectuelle français. Entre autres, toute réutilisation, diffusion, commercialisation, reproduction et représentation, totale ou partielle, d’éléments du site à d’autres fins, sans l’autorisation préalable écrite de domestiquerletemps.com, est interdite et peut être constitutive du délit de contrefaçon et/ou d’atteinte aux droits voisins du droit d’auteur.</p>
<p><strong>Contenu du site :</strong><br />
doganima.org se réserve le droit de corriger, à tout moment et sans préavis, le contenu de ce site. En outre, domestiquerletemps.com décline toute responsabilité en cas de retard, d’erreur ou d’omission quant au contenu des présentes pages de même qu’en cas d’interruption ou de non-disponibilité du service.<br />
Les informations contenues dans ce site ne sont mises à la disposition des internautes qu’à titre indicatif. En particulier, les informations sur les produits et services, les adresses, les noms et contacts ne sont en aucun cas exhaustifs. Toutes ces informations sont susceptibles d’être modifiées à tout moment et ne sont donc pas contractuelles.</p>

<p><strong>Liens Hypertextes :</strong><br />
La création de liens hypertextes vers le site doganima.org ne saurait, en aucun cas, engager la responsabilité de doganima.org. Les liens hypertextes établis en direction d’autres sites à partir de doganima.org ne sauraient, en aucun cas, engager la responsabilité de domestiquerletemps.com.<br />
<p><strong>Confidentialité des données des utilisateurs :</strong><br />
doganima.org est le seul destinataire des informations nominatives que l’utilisateur lui transmet. doganima.org s’engage à ne pas communiquer les informations personnelles à des tiers. Vous devez également vous abstenir, s’agissant des données personnelles auxquelles vous accédez, de toute collecte, de toute utilisation détournée, et d’une manière générale, de tout acte susceptible de porter atteinte à la vie privée ou à la réputation des personnes.</p>
<strong>Cookies :</strong><br />
doganima.org souhaite implanter un cookie dans votre ordinateur. Ce cookie enregistrera les informations relatives à votre navigation sur notre site web et stockera les informations que vous aurez saisies durant votre visite sur ledit site, comme par exemple vos heures de visite et les pages que vous avez consultées. Ainsi, lors de vos prochaines visites, vous n’aurez plus besoin de saisir ces informations une nouvelle fois.</p>
<p>Vous pouvez vous opposer à l’enregistrement des cookies en configurant votre navigateur de la manière suivante :</p>
<p><strong>Pour Microsoft Internet Explorer 6.0 et 7.0 :</strong><br>
Choisissez le menu «&nbsp;Outils&nbsp;», puis «&nbsp;Options Internet&nbsp;»<br>
Cliquez sur l’onglet «&nbsp;Confidentialité&nbsp;»<br>
Sélectionnez le niveau souhaité à l’aide du curseur.</p>
<p><strong>Pour Microsoft Internet Explorer 5 :</strong><br>
Choisissez le menu «&nbsp;Outils&nbsp;», puis «&nbsp;Options Internet&nbsp;»<br>
Cliquez sur l’onglet «&nbsp;Sécurité&nbsp;»<br>
Sélectionnez «&nbsp;Internet&nbsp;» puis «&nbsp;Personnaliser le niveau&nbsp;»<br>
Repérez la rubrique «&nbsp;cookies&nbsp;» et choisissez l’option qui vous convient.</p>
<p><strong>Pour Opéra 6.0 et au-delà :</strong><br>
Choisissez le menu «&nbsp;Fichier&nbsp;»&gt;&nbsp;»Préférences&nbsp;»<br>
Vie Privée</p>
<p><strong>Pour Mozilla firefox :</strong><br>
Choisissez le menu «&nbsp;outil &nbsp;» puis «&nbsp;Options&nbsp;»<br>
Cliquez sur l’icône «&nbsp;vie privée&nbsp;»<br>
Repérez le menu «&nbsp;cookie&nbsp;» et sélectionnez les options qui vous conviennent</p>
<p><strong>Pour Google Chrome :</strong><br>
Cliquez sur l’icône représentant une clé à molette<br>
Choisissez le menu “Options”<br>
Cliquez sur l’onglet Options avancées<br>
Cliquez sur l’option Paramètres de contenu de la section «&nbsp;Confidentialité&nbsp;»<br>
Dans la boîte de dialogue Paramètres de contenu qui s’affiche, cliquez sur l’onglet Cookies.<br>
Droits d’auteur</p>
<p><strong>Analyse du trafic</strong></p>
<p>Ce site utilise Google Analytics, un service d’analyse du trafic de site internet fourni par Google. Google Analytics utilise des cookies, qui sont des fichiers textes hébergés sur votre ordinateur, pour aider le site internet à analyser l’utilisation du site par ses utilisateurs.</p>
<p>Les données générées par les cookies concernant votre utilisation du site (y compris votre adresse IP) sont transmises et stockées par Google sur des serveurs situés aux Etats-Unis. Google utilise ces informations dans le but d’évaluer l’utilisation du site par ses visiteurs, de compiler des rapports sur l’activité du site à destination de son éditeur et de fournir d’autres services relatifs à l’activité du site et à l’utilisation d’Internet.</p>
<p>Google est susceptible de communiquer ces données à des tiers en cas d’obligation légale ou lorsque ces tiers traitent ces données pour le compte de Google, y compris notamment l’éditeur de ce site. Google s’engage à ne jamais recouper votre adresse IP avec toute autre donnée détenue par Google.</p>
<p>Vous pouvez désactiver l’utilisation de cookies en sélectionnant les paramètres appropriés de votre navigateur. Cependant, une telle désactivation pourrait empêcher l’utilisation de certaines fonctionnalités de ce site. En utilisant ce site Web, vous acceptez que Google traite des données vous concernant de la manière et aux fins décrites ci-dessus.</p>
</div>
</div>
</div>
<br /><br /> 
</section>	
<?php include("inc/footer.inc.php"); ?>
</body>
</html>
 