<header>
<div class="header">

<!-- C'est le bouton de déconnexion -->
<form action="disconnect.php" method="post" enctype="multipart/form-data">
<?php
    if ($_COOKIE["firstname"]) { 
	   if ($_COOKIE["BY"]) {
           print("Bienvenue ".$_COOKIE["firstname"]."&nbsp;&nbsp;&nbsp;&nbsp;");
	   } else {
	  	   print($_COOKIE["firstname"]."&nbsp;&nbsp;&nbsp;&nbsp;"); 
       }			  
	}	
?>
<input type="submit" name="deconnection" class="butsum" value="Déconnexion" />
</form>
</div>

<!-- Logo non visible uniquement chez Safari -->
<a href="index.php"><img class="logo" id="doglog" src="img/dogan_logo.jpg" OnMouseOver="document.images['doglog'].style['border']='1px solid #000000';" OnMouseOut="document.images['doglog'].style['border']='1px solid white';" alt="DogAnima Garde de chiens PetSitting" title="DogAnima Garde de chiens PetSitting"></a>
<div class="center3">

<!-- Banner -->
<img src="img/dogan_1_x.jpg" alt="DogAnima" title="DogAnima" />
</div>
<nav>
<div id="menu">
<ul>
<li><a href="messages.php?gzpgj=22369oml310" title="Visualiser les messages">Visualiser les messages</a></li>
<li><a href="choice2.php?urdel=32250rop212" title="Modifier le texte">Modifier le texte</a></li>
<li><a href="disconnect.php" title="Quitter">Quitter</a></li>
</ul>
</div>
</nav>
</header>
