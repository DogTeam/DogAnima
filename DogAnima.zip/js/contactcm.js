// Fichier contactcl.js
// Pour contact.php
// Projet DogAnima
// Auteurs: Laurent Gouthière & Emmanuel Leblanc
// Création: 12/12/2015
// MAJ du 20/01/2015
// MAJ du 13/04/2016

var resultat;
var bloc;
var chiffre1 = randomize(10);
bloc = document.getElementById('n1');
bloc.innerHTML = chiffre1;
var chiffre2 = randomize(10); 
bloc = document.getElementById('n2');
bloc.innerHTML = chiffre2;
resultat = parseInt(chiffre1) + parseInt(chiffre2);

function randomize(n) {
// Renvoie un nombre aléatoire de 1 à n	

   return (Math.floor((n)*Math.random()+1));
} 
  
function checkCaptchaMat(numcapt, resultat) {
// Test la Captcha Mathématique
	
   var bloc;	
   // Résultat exacte : retour vrai
   if (numcapt == resultat) {
	  document.getElementById('answer').style.color="#ececec";
	  return true;
   } else { // Résultat faux : retour faux
	  document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Champ vide - Entrez le résultat de la somme !]";
	  form.numcapt.focus(); 
	  return false;
   }
}

function isempty(atextfield) {
// Test si un champ est vide
	
   if ((atextfield.value.length == 0) || (atextfield.value == null)) {
      return true;
   } else { return false; }
}

function checkLastName(name) {
// Test le Nom	

   var bloc; 
   var r;
   // Si le champ est vide : retour faux
   if (isempty(name)) {
	  name.value = name.value.toUpperCase();  
	  document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Champ vide - Entrez le Nom !]";
	  form.lastname.focus(); 
	  return false;	
   }	
   // Si il contient des chiffres : retour faux
   if (name.value.match(/[0-9]/)) {
	   name.value = name.value.toUpperCase();  
	   document.getElementById('answer').style.color="red";
	   bloc = document.getElementById('answer');
	   bloc.innerHTML = "*[Caractère(s) non valide(s) - Entrez le Nom !]";
	   form.lastname.focus(); 
	   return false;
   }       
   name.value = name.value.toUpperCase();
   document.getElementById('answer').style.color="#ececec";
   return true; 
}	

function checkFirstName(name) {
// Test le Prénom
	
   var bloc; 
   var r;
   // Si le champ est vide : retour faux
   if (isempty(name)) {
	  document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Champ vide - Entrez le Prénom !]";
	  form.firstname.focus(); 
	  return false;	
   }	
   // Si le champs contient des chiffres : retour faux
   if (name.value.match(/[0-9]/)) {
	  document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Caractère(s) non valide(s) - Entrez le Prénom !]";
	  form.firstname.focus();
	  return false;
   }       
   document.getElementById('answer').style.color="#ececec";
   return true; 
}

function checkTel(tel) {
// Test le numéro de téléphone

   var bloc;
   var r;   
   // Si le champs est vide: retour faux
   if (isempty(tel)) {
	  document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Champ vide - Entrez le Téléphone !]";
	  tel.focus(); 
	  return false;	
   }	 	
   // Si le champ ne contient pas les caractéres spécifiques de téléphone: retour au formulaire
   if (!tel.value.match(/^(0[1-68])(?:[ _.-]?(\d{2})){4}$/)) {
      document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Caractère(s) non valide(s) - Entrez le Téléphone !]";
	  tel.focus(); 
	  return false;
   }
   document.getElementById('answer').style.color="#ececec";
   return true; 
}

function checkEMail(em) {
// Test l'email
	
   var bloc;  	
   var r;
   // Si le champ e-mail est vide ou ne contient pas les caractères suivants: retour au formulaire
   if (isempty(em) || (!em.value.match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/))){ 
	  document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Champ vide ou e-mail non valide - Entrez l'e-mail !]";
      em.focus();
      return false; 
   } 	
   document.getElementById('answer').style.color="#ececec";	
   return true; 
}	

function checkMessage(mes) {
// Test si il y a un message
	
   var bloc;	
   var r = /[<>#{}]/;
   if ((isempty(mes)) || (r.test(mes.value))) {
	  document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Champ vide ou caractères non valide ([<>#{} interdits) - Entrez le message !]";
      mes.focus();
      return false;
   }	
   document.getElementById('answer').style.color="#ececec";
   return true;
}	

function checkIntervenant(interv) {
// Met le focus sur intervenant qui n'est pas obligatoire
	
   document.getElementById('answer').style.color="#ececec";
   interv.focus();
}	

function checkSubject(sub) {
// Met le focus sur le sujet qui est obligatoire	
   document.getElementById('answer').style.color="#ececec";
   sub.focus();
}	

function ValidateFormCM(form)
// Teste les différents champs du formulaire
{  
   // Si le champ nom est vide ou contient des chiffres : retour au formulaire 
   if (!checkLastName(form.lastname)) {  
	  return false;
   }
   
   // Si le champ nom est vide ou contient des chiffres : retour au formulaire 
   if (!checkFirstName(form.firstname)) { 
      return false; 
   }
   
   // Si le champ est vide ou que le numéro de téléphone ne contient pas des chiffres : retour au formulaire
   if (!checkTel(form.tel)) { 
      return false; 
   }
   
   // Si le champ e-mail est vide ou est invalide : retour au formulaire
   if (!checkEMail(form.email)) { 
      return false; 
   }
   
   // L'intervenant n'est pas un champ obligatoire
   /*
   if (isempty(form.intervenant)) {
      r=confirm("Champ vide - Entrez l'intervenant !");
	  if (r == false) { 
	     location.href="contact.php";  
	     return false; 
	  }
	  document.getElementById('answer').style.color="red";
	  bloc = document.getElementById('answer');
	  bloc.innerHTML = "*[Champ vide - Entrez l'intervenant !]";
      form.intervenant.focus();
      return false;
   }
   */
   
   // Si le champ message est vide ou contient des caractères inderdits : retour au formulaire
   if (!checkMessage(form.message)) {
      return false;
   }
   
   if (!checkCaptchaMat(form.numcapt.value, resultat)) {
      return false;
   }	   
   
   document.getElementById('answer').style.color="#ececec";
   
   return true;
} 