<!DOCTYPE html>
<!-- Projet DogAnima            
     choice1.php                
     Création 14/04/2016        
	 MAJ du 14/04/2016     
	 MAJ du 25/04/2016     
-->	 
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
-->
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
<meta name="description" content="Garde de chiens en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Garde de chiens à domicile ou en accueil</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<?php include ("inc/headerchoice2.inc.php"); ?>
<p></p>
<div class="center">
<h1>
<?php 
    if (isset($_GET["urdel"])) { // Si il y a quelques chose dans le $_GET
	   $tp = $_GET["urdel"];
       if ($tp != "32250rop212") { // Si mauvais code retour à la page choice1
           header("Location: ./disconnect.php"); 
	   }
    } else {
		header("Location: ./disconnect.php"); 
    }		
?>
</h1>
<p>&nbsp;</p>
Votre choix : Menu Horizontal
</div>
<p></p>
<?php include("inc/footer.inc.php"); ?>
</body>
</html>