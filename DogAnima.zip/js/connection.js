 function checkLogin() {
   var x = document.getElementById("idlogin"); 
   var bloc;
   if (x.value.length == 0) {
	  document.getElementById("errormsg").style.color="red";
	  bloc = document.getElementById("errormsg");
	  bloc.innerHTML = "*[Entrez le login !]";
	  document.getElementById("idlogin").style.borderColor = "red";
	  x.focus();
      return false;
   } 
   document.getElementById("errormsg").style.color="white";
   document.getElementById("idlogin").style.borderColor = "grey";
   return true;
}	

function checkPassword() {
   var x = document.getElementById("idpassword");
   var bloc;
   if (x.value.length == 0) {
	  document.getElementById("errormsg").style.color="red";
	  bloc = document.getElementById("errormsg");
	  bloc.innerHTML = "*[Entrez le mot de passe !]";
	  document.getElementById("idpassword").style.borderColor = "red";
	  x.focus();
      return false;
   } 
   document.getElementById("errormsg").style.color="white";
   document.getElementById("idpassword").style.borderColor = "grey";
   return true;	   
}	
	
function validateForm(form) {
   if (!checkLogin()) {
      return false;
   }
   if (!checkPassword()) {
   	  return false; 
   }	
   document.getElementById("errormsg").style.color="#ececec";    
   return true;	
}	
