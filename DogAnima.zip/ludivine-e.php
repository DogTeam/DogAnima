<!DOCTYPE html>
<!--                            
    Projet DogAnima            
    ludivine-e.php
    Création du 19/01/2015
	MAJ du 19/01/2015
--> 
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="index,nofollow" />
<title>DogAnima - Tarifs pour la garde à domicile ou en acceuil dans une famille - Ludivine</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<?php include ("inc/header.inc.php"); ?>
<body>
<?php include_once("inc/analyticstracking.php") ?>
<div id="main">
<h1 class="title"><strong><em>Dog sitter à Villeperdue 37</em></strong></h1>
</div>
<section>
<div class="left">
<div class="intv1">
<h2>Ludivine, dog sitter à Villeperdue 37</h2>
<p></p>
Possédant un <strong>berger allemand</strong>, Ludivine garde votre animal chez elle ou en se rendant <strong>à votre domicile</strong>.<br/>
Demeurant à <strong>Villeperdue</strong> au sud de <strong>Sorigny</strong> son tarif est de 15 euros par jour.
<p></p>
<p></p>
<div class="center">
<img src="img/Ludivine-E.jpg" height="360" width="360" alt="Ludivine dog sitter à Villeperdue 37" title="Ludivine dog sitter à Villeperdue 37" />
</div>
</div>
<div class="intv1bis">
<h2>Une future professionnelle</h2>
<p>Se destinant au métier de <strong>maître-chien</strong> dans la Gendarmerie, Ludivine profite de son activité de <strong>pet sitter</strong> pendant ses études pour découvrir un maximum d'animaux aux caractères différents. Elle garde des chiens depuis 3 ans et a acquis une sérieuse <strong>expertise cynophile</strong> complétée par des stages préparatoires en centre de <strong>dressage canin</strong>. Elle pourra vous donner quelques conseils en matière d'éducation de votre <strong>animal de compagnie</strong>.</p>
</div>
<div class="intv2">
<iframe src="https://www.google.com/maps/d/embed?mid=zRmiDXqgCE7s.kWCU2FZxQKOs" width="470" height="296"></iframe>
</div>
</section>
<table style="width: 100%;">
<tr>
<td class="vertical-align: top;border-radius: none;">
<?php include("inc/footer.inc.php"); ?>
</td>
</tr>
</table>
</body>
</html>