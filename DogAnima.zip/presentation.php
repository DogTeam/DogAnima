<!DOCTYPE html>                        
<!-- Projet DogAnima            
     presentation.php     
     Création du 13/11/2015 
     MAJ du 19/01/2015 
	 MAJ du 20/04/2016
	 MAJ du 24/04/2016
	 Rem    : Charge le document à partir de la base de données
--> 
<html lang="fr"> 
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="description" content="Garde de chien personnalisée (dog sitting) en Indre et Loire par des spécialistes canins. Prestations réalisées en famille d'accueil ou à votre domicile."/>
<meta name="robots" content="index,follow" />
<title>Spécialistes de la garde de chien (dog sitter) en Indre-et-Loire</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href = "css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<?php include("inc/headerpres.inc.php"); ?>  
<body>
<?php include_once("inc/analyticstracking.php") ?>
<?php 
include("inc/connect.inc.php"); // Paramètres de connexion à la base de données 

// Le but ici est de rechercher le titre, le texte de gauche et le texte de droite dans la base de données et de l'afficher
if ($id = mysqli_connect($dbhost, $dbuser, $dbpassw)){
    mysqli_query($id, "SET NAMES 'utf8'");
    if (mysqli_select_db($id, $dbname)) { 
	 $request = "select content_title, content_text1, content_text2, content_text3 from content where content_id >= content_id and trim(content_name) = 'presentation.php'";
     if ($result = mysqli_query($id, $request)){
        while ($ligne = mysqli_fetch_row($result)){
		   $title = $ligne[0];
	 // $text1 = $ligne[1];
		   $text21 = $ligne[2];
		   $text22 = $ligne[3];
		}		    
        mysqli_free_result($result); 		
	    mysqli_close($id);   	   
     } else {
          mysqli_close($id);    
          header("Location: ./index.php");	
     }		  
  } else {
       mysqli_close($id);     
	   header("Location: ./index.php");	
  }	   
} else {   
	 header("Location: ./index.php");	
}	 
?>

<!-- h1 en dehors de section -->
<!-- Affichage du titre 
title signifie titre de la page
-->
<h1 class="title"><strong><em><?php print($title); ?></em></strong></h1>

<section>
<!-- Affichage du texte du bloc gauche 
present11 signifie page présentation bloc de gauche.
-->
<div class="pres11"><?php print($text21); ?>
<p></p> 
</div>

<!-- Affichage du texte du bloc droit 
present12 signifie page présentation bloc de droite 
-->
<div class="pres12"><?php print($text22); ?>

<!-- image faisant suite au texte de droite (round signifie image à bords arrondis) -->
&nbsp;<img src="img/dogan_3.jpg" height="240" width="450" alt="DogAnima" title="DogAnima" class="round" />
</div>
</section>	

<!-- Pied de page -->
<?php include("inc/footer.inc.php"); ?>
</body>
</html>
