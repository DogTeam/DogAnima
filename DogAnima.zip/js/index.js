function openWindowPage(p, w, h) {
   popupWin=window.open(p,'display', 'menubar=no, toolbar=no, location=no, directories=no, status=no, width='+w+', height='+h+'');
}