<!DOCTYPE html>
<!--                            
    Projet DogAnima            
    nicolas_m.html                
    Création du 19/01/2015
	MAJ du 19/01/2015
--> 
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="index,nofollow" />
<title>DogAnima - Tarifs pour la garde à domicile ou en acceuil dans une famille - Jade</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<?php include_once("inc/analyticstracking.php") ?>
<?php include ("inc/header.inc.php"); ?>
<div id="main">
<h1 class="title"><strong><em>Dog sitting à Cormery 37</em></strong></h1>
</div>
<section>
<div class="left">
<div class="intv1">
<h2>Jade, dog sitter à Cormery</h2>
<p></p>
Possédant deux chats et <strong>trois chiens de race</strong>. Jade peut s'occuper de votre animal chez vous ou à son domicile.<br/>
Demeurant à <strong>Cormery</strong> au sud de Tours son tarif est de 15 euros par jour.
<p></p>
<div class="center">
<img src="img/Jade-L.jpg" height="360" width="360" alt="Jade dog sitter à Cormery 37" title="Jade dog sitter à Cormery 37" />
</div>
</div>
<div class="intv1bis">
<h2>Une amoureuse des chiens</h2>
<p>Jade et les <strong>toutous</strong>, c'est une histoire qui remonte à son enfance et aux deux <strong>labradors</strong> que possédaient déjà ses parents à sa naissance. Dire qu'elle est tombée dans la gamelle étant bébé est à prendre au sens propre comme au figuré ! Elle n'a cessé depuis d'élever des chiots et s'est spécialisée depuis 3 ans dans le <strong>dressage de chiens d'aveugles</strong> à <strong>Cormery</strong>. Inutile de dire qu'elle saura parfaitement choyer votre compagnon à quatre pattes</strong>.</p>
</div>
<div class="intv2">
<iframe src="https://www.google.com/maps/d/embed?mid=zRmiDXqgCE7s.kWCU2FZxQKOs" width="470" height="296"></iframe>
</div>
</section>
<table style="width: 100%;">
<tr>
<td>
<?php include("inc/footer.inc.php"); ?>
</td>
</tr>
</table>
</body>
</html>