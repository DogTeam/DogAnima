<!DOCTYPE html>
<!-- Projet DogAnima            
     choice1.php                
     Création 14/04/2016        
	 MAJ du 14/04/2016        
-->
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
-->
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
<meta name="description" content="Garde de chiens en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="index,follow" />
<title>DogAnima - Garde de chiens à domicile ou en accueil</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<?php include ("inc/headerconnect.inc.php"); ?>
<p></p>
<div class="center">
<h1>
<?php 
    if (isset($_GET["gjklp"])) { 
	$tp = $_GET["gjklp"];
    if ($tp == "12269jkl309") {
       if ($_COOKIE["firstname"]) { 
	      if ($_COOKIE["BY"]) {
              print("Bienvenue ".$_COOKIE["firstname"]);
		  } 		  
	   }
	}   
	} else { header("Location: ./disconnect.php"); }
?>
</h1>
<form name="loadcsv" action="actionloadcsv.php" method="POST" enctype="multipart/form-data" >
<input type="submit" value="Télécharger fichier CSV">
</form>
<p>&nbsp;</p>
Votre choix : Menu Horizontal
</div>
<p></p>
<?php include("inc/footer.inc.php"); ?>
</body>
</html>