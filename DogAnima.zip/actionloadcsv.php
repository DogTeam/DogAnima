﻿<?php include ("inc/connect.inc.php");

/* Date : 21/05/2016 */
/* But  : Création puis téléchargement du fichier message.csv */

/* Nouvelle version en PDO: Création d'un fichier .csv contenant les messages */
    try {
    $connection = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpassw);
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  }
   catch (Exception $e) {
   print('Erreur : '.$e->getMessage());
	 exit;
  }
  try {
	 $fic = "message.csv";	
     $f = fopen("$fic", "r+");
     foreach($connection->query('select msge_id, msge_ema, msge_subj, msge_txt from msge') as $row) {
     fwrite($f, $row[0].";".$row[1].";".$row[2].";".$row[3]."\n");
  }
  $connection = null;
  fclose($f);
  } catch (Exception $e) {
     print('Erreur : '.$e->getMessage());
   header("location: ./choice1.php?gjklp=12269jkl309");
	   exit;
  }
  /* Chemin absolu du fichier message.csv et téléchargement */
  $url = "message.csv";
  $mm_type="application/octet-stream";
  header("Cache-Control: public, must-revalidate");
  header("Pragma: hack");
  header("Content-Type: " . $mm_type);
  header("Content-Length: " .(string)(filesize($url)) );
  header('Content-Disposition: attachment; filename="'.basename($url).'"');
  header("Content-Transfer-Encoding: text\n");             
  $fp = fopen($url, 'rb');
  $buffer = fread($fp, filesize($url));
  fclose ($fp);             
  print $buffer;
?>