<header>
<table class="header" style="height: 27px;"> <!-- On ne peut pas enlever le style ici du fait que ce n'est pas toujours la même valeur -->
<tr>
<td>
<div class="warning" style="visibility: hidden;">
<marquee>
Attention: Ce site est un exercice dans le cadre d'une formation du CNAM - L'association DogAnima et les personnes présentées sont fictives.
</marquee>
</div>
</td>
</tr>
</table>
<!-- Logo non visible uniquement chez Safari -->
<a href="index.php"><img class="logo" id="doglog" src="img/dogan_logo.jpg" OnMouseOver="document.images['doglog'].style['border']='1px solid #000000';" OnMouseOut="document.images['doglog'].style['border']='1px solid white';" alt="DogAnima Garde de chiens PetSitting" title="DogAnima Garde de chiens PetSitting"></a>
<div class="center3">
<!-- Image de banner -->
<img src="img/dogan_1_x.jpg" alt="DogAnima" title="DogAnima" />
</div>
<br />
<nav>
<div id="menu" class="men17">
<ul>
<li><a href="index.php" title="Accueil DogAnima" >Accueil</a></li>
<li><a href="presentation.php" title="Présentation DogAnima">Pr&eacute;sentation</a></li>
<li><a href="tarifs.php" title="Tarifs DogAnima">Tarifs</a> 
    <ul class="niveau2">
    <li><a href="nicolas-m.php" title="Nicolas M.">Nicolas M.</a></li><br /><br />
	<li><a href="viviane-g.php" title="Viviane G.">Viviane G.</a></li><br /><br />
	<li><a href="jade-l.php" title="Jade L.">Jade L.</a></li><br /><br />
	<li><a href="ludivine-e.php" title="Ludivine E.">Ludivine E.</a></li><br /><br />
	<li><a href="pauline-b.php" title="Pauline B.">Pauline B.</a></li>
    </ul>
</li>
<li><a href="contact.php" title="Contact DogAnima">Contact</a></li>
</ul>
</div>
</nav>
</header>

