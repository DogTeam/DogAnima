 function checkLogin() {
   var x = document.getElementById("idlogin"); 
   var bloc;
   if ((x.value.match(/</)) || (x.value.length == 0)) {
	  document.getElementById("errormsg").style.color="red";
	  bloc = document.getElementById("errormsg");
	  bloc.innerHTML = "*[Entrez le login ou des caractères valides (pas <) !]";
	  document.getElementById("idlogin").style.borderColor = "red";
	  x.focus();
      return false;
   } 
   document.getElementById("errormsg").style.color="white";
   document.getElementById("idlogin").style.borderColor = "grey";
   return true;
}	
	
function checkPassword() {
   var x = document.getElementById("idpassword");
   var bloc;
   if ((x.value.match(/[A-Z]/)) && (x.value.match(/[a-z]/)) && (x.value.match(/[0-9]/)) && (x.value.length(x) >= 6)) {
	  document.getElementById("errormsg").style.color="white"; 
	  document.getElementById("idlogin").style.borderColor = "grey";
	  return true;
   } else {
	  document.getElementById("errormsg").style.color="red";
	  bloc = document.getElementById("errormsg");
	  bloc.innerHTML = "*[Entrez le mot de passe. Au moins 6 caractères (avec au moins une majuscule, une minuscule et un chiffre) !]";
	  document.getElementById("idpassword").style.borderColor = "red";
	  x.focus();
      return false;
   }	   
}	
	
function validateForm(form) {
   if (!checkLogin()) {
      return false;
   }
   if (!checkPassword()) {
   	  return false; 
   }	
   document.getElementById("errormsg").style.color="#ececec";    
   return true;	
}	
