<?php
// Constantes de connexion au serveur local

$dbhost="localhost";
$dbuser="root";
$dbpassw=""; 
$dbname="doganima";

// Sur serveur OVH
// $dbhost="doganimahmdogani.mysql.db";
// $dbuser="doganimahmdogani";
// $dbpassw="Doganima1"; 
// $dbname="doganimahmdogani";
?>