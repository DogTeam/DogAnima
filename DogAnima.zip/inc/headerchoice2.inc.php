<header>
<div class="header">

<!-- C'est le bouton de déconnexion -->
<form action="disconnect.php" method="post" enctype="multipart/form-data">
<?php
    // Pour le moment on ne crypte pas les URLS c'est juste un test
    //if ($_GET["gjklp"] == "12269jkl309") {
       if (isset($_COOKIE["firstname"])) { 
          print($_COOKIE["firstname"]."&nbsp;&nbsp;&nbsp;&nbsp;");
	   }
	//} else { header("Location: ./disconnect.php"); }  
?>
<input type="submit" name="deconnection" class="butsum" value="Déconnexion" />
</form>
</div>

<!-- Logo non visible uniquement chez Safari -->
<a href="index.php"><img class="logo" id="doglog" src="img/dogan_logo.jpg" OnMouseOver="document.images['doglog'].style['border']='1px solid #000000';" OnMouseOut="document.images['doglog'].style['border']='1px solid white';" alt="DogAnima Garde de chiens PetSitting" title="DogAnima Garde de chiens PetSitting"></a>
<div class="center3">

<!-- Banner -->
<img src="img/dogan_1_x.jpg" alt="DogAnima" title="DogAnima" />
</div>

<nav>
<div id="menu">
<ul>
<li><a href="indpage.php?virop=22560fuc940" title="Modifier la page d'accueil">Accueil (index.php)</a></li>
<li><a href="prespage.php?indop=113246dif940" title="Modifier la page de présentation">Présentation (presentation.php)</a></li>
<li><?php setcookie("BY", 0); ?><a href="choice1.php?gjklp=12269jkl309" title="Quitter" >Quitter</a></li>
</ul>
</div>
</nav>

</header>
