<!DOCTYPE html>
<!-- Projet DogAnima            
     messages.php     
     Création du 14/04/2016 
	 MAJ du 15/04/2016
	 MAJ du 16/04/2016
	 MAJ du 03/05/2016
	 MAJ du 11/05/2016
	 MAJ du 12/05/2016
--> 
<html lang="fr"> 
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Visualisation des messages de contact</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href = "css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<header>
<div class= "header">
<form action="disconnect.php" method="post" enctype="multipart/form-data">
<?php 
    if (isset($_GET["gzpgj"])) { 
	   $tp = $_GET["gzpgj"];
       if ($tp == "22369oml310") {
          if ($_COOKIE["firstname"]) { 
             print($_COOKIE["firstname"]."&nbsp;&nbsp;&nbsp;&nbsp;");
	      }
	   }
    } else { header("Location: ./disconnect.php"); }	   
?>
<input type="submit" class="butsum" value="Déconnexion" />
</form>
</div>
<!-- Logo non visible uniquement chez Safari -->
<a href="index.php"><img class="logo" id="doglog" src="img/dogan_logo.jpg" OnMouseOver="document.images['doglog'].style['border']='1px solid #000000';" OnMouseOut="document.images['doglog'].style['border']='1px solid white';" height="auto" width="155" alt="DogAnima Garde de chiens PetSitting" title="DogAnima Garde de chiens PetSitting"></a>
<div class="center3">
<!-- Banner -->
<img src="img/dogan_1_x.jpg" alt="DogAnima" title="DogAnima" />
</div>
<nav>
<div id="menu">
<ul>
<li><a href="messages.php?gzpgj=22369oml310" title="Visualiser les messages">Visualiser les messages</a></li>
<li><a href="choice2.php?urdel=32250rop212" title="Modifier le texte">Modifier le texte</a></li>
<li><a href="index.php" title="Quitter">Quitter</a></li>
</ul>
</div>
</nav>
</div>
</header>
<!-- h1 en dehors de section -->
<h1 class="title"><strong><em>Visualisation des messages de contact</em></strong></h1>
<section >
<div style="width: 960px; text-align: center; margin-left: auto; margin-right: auto;">
<div style="text-align: left;">
<div class="present11;">
<table>
<tr>
<td style="width: 25px; padding-left: 20px; vertical-align: top;">
<?php
print("<b>n</b>&nbsp;:");
?>
</td>
<td style="width: 50px; padding-left: 20px; vertical-align: top;">
<?php
print("<b>Courriel</b>&nbsp;:");
?>
</td>
<td style="width: 180px; padding-left: 20px; vertical-align: top;">
<?php
print("<b>Sujet</b>&nbsp;:");
?>
</td>
<td style="width: 480px; padding-left: 20px; vertical-align: top;">
<?php
print("<b>Message</b>&nbsp;:");
?>
</td>
</tr>
<?php
include("inc/connect.inc.php");
print('<p></p>');
/* Ancienne version en mysqli: Affichage des messages: id, mail, sujet, texte du message
$OK = 1;
if ($id = mysqli_connect($dbhost, $dbuser, $dbpassw)){
  if (mysqli_select_db($id, $dbname)){ 
	 $request = "select msge_id, msge_ema, msge_subj, msge_txt from msge";  
     if ($result = mysqli_query($id, $request)){ 
        while ($row = mysqli_fetch_row($result)){
		   if ($OK) {
              print("<tr style='background-color: white;'>"); 	
		      $OK = 0;
		   } else {
		      print("<tr style='background-color: #ececec;'>"); 		
		      $OK = 1;
           }			
		   print('<th style="width: 25px; padding-left: 20px; vertical-align: top; border-top: 1px solid grey;">');
      	   print($row[0]); // id
		   print("</th>");
		   print('<td style="width: 50px; vertical-align: top; padding-left: 20px; border-top: 1px solid grey;">');
		   print($row[1]); // email		   
		   print("</td>");
		   print('<td style="width: 180px; vertical-align: top; padding-left: 20px; border-top: 1px solid grey;">');
		   print($row[2]); // subject
		   print("</td>");
		   print('<td style="width: 480px; vertical-align: top; padding-left: 20px; border-top: 1px solid grey;">');
		   print('<div style="width: 480px; word-wrap: break-word;">');
		   print($row[3]); // message
		   print("</div>");
		   print("</td>");
  		   print("</tr>");   
		} // while		
        print("</table>");
		mysqli_close($id); 
     } // if		     		 
     else {
        mysqli_close($id); 
        print("</table>");		
	 }	
  } else {
	  mysqli_close($id); 
	  print("</table>");	
      print("Pas de messages");
  }	  
 } else {  
     print("</table>");	
     print("Pas de messages");
 }  
 */

/* Nouvelle version en PDO: Affichage des messages: id, mail, sujet, texte du message */
  $OK = 1;
  try {
    $connection = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpassw);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  } catch (Exception $e) {
       print('Erreur : '.$e->getMessage());
	   header("location: ./choice1.php?gjklp=12269jkl309");
	   exit;
  }
  try {
  foreach($connection->query('select msge_id, msge_ema, msge_subj, msge_txt from msge') as $row) {
	 if ($OK) {
        print("<tr style='background-color: white;'>"); 	
		$OK = 0;
	 } else {
	      print("<tr style='background-color: #ececec;'>"); 		
	      $OK = 1;
     }			
	 print('<th style="width: 25px; padding-left: 20px; vertical-align: top; border-top: 1px solid grey;">');
     print($row[0]); // id
	 print("</th>");
	 print('<td style="width: 50px; vertical-align: top; padding-left: 20px; border-top: 1px solid grey;">');
	 print($row[1]); // email		   
	 print("</td>");
	 print('<td style="width: 180px; vertical-align: top; padding-left: 20px; border-top: 1px solid grey;">');
	 print($row[2]); // subject
	 print("</td>");
	 print('<td style="width: 480px; vertical-align: top; padding-left: 20px; border-top: 1px solid grey;">');
	 print('<div style="width: 480px; word-wrap: break-word;">');
	 print($row[3]); // message
	 print("</div>");
	 print("</td>");
  	 print("</tr>");    
  }
  print("</table>");
  $connection = null;
  } catch (Exception $e) {
       print('Erreur : '.$e->getMessage());
	   header("location: ./choice1.php?gjklp=12269jkl309");
	   exit;
  }
?>
</div>
</div>
</div>
</section>	
<?php include("inc/footer.inc.php"); ?>
</body>
</html>
