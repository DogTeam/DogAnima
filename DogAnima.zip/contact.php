﻿<!DOCTYPE html>
<!--           
    Projet DogAnima            
    contact.php               
    Création 13/11/2015         
	MAJ du 20/01/2015
	MAJ du 07/05/2016
	MAJ du 09/05/2016
	MAJ du 10/05/2016
	But: Formulaire de contact renforcé en php
--> 
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<!--
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
-->
<meta name="robots" content="noindex,nofollow" />
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire DogAnima"/>
<title>DogAnima - Contact de l'association soit par formulaire soit par téléphone ou Fax</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<?php include ("inc/header.inc.php"); ?>

<div class="left">
<h1 class="title"><strong><em>Nous contacter</em></strong></h1>
</div>
<section>
<p></p>
<table class="contact">
<tr>
<td>
<div id="begin"></div>
<form action="actionformcm.php" method="post" enctype="multipart/form-data" name="form" OnSubmit="return ValidateFormCM(this);">
<div class="center">Pour nous contacter, veuillez remplir le formulaire suivant :</div>
<br />
<?php
   session_start();
?>
<table class="center75">
<tr>
<td class="valigntop">
<span class="right" id="answer" style="color: red;">&nbsp;<?php if (isset($_SESSION['errormsg'])) { print($_SESSION['errormsg']);} ?></span>
</td>
</tr>
</table>
<table class="center75">
<tr>
<td class="valigntop">
* Nom    :
</td>
<td class="valigntop">
<div class="left"> 
<input type="text" name="lastname" size="35" value= "<?php if (isset($_SESSION['lastname'])) { print($_SESSION['lastname']);}?>" OnClick="checkLastName(lastname);"/>
</div>
</td>
</tr>

<tr>
<td class="valigntop">
* Prénom    :
</td>
<td class="valigntop">
<div class="left"> 
<input type="text" name="firstname" size="35" value= "<?php if (isset($_SESSION['firstname'])) { print($_SESSION['firstname']);}?>" OnClick="checkFirstName(firstname);"/>
</div>
</td>
</tr>

<tr>
<td class="valigntop">
* Téléphone :
</td>
<td class="valigntop">
<div class="left">
<input type="text" name="tel" size="10" value= "<?php if (isset($_SESSION['tel'])) { print($_SESSION['tel']);}?>" OnClick="checkTel(tel);"/>
</div>
</td>
</tr>
<tr>

<td class="valigntop">
* e-mail                 :
</td>
<td class="valigntop">
<div class="left">
<input type="text" name="email" size="35" value= "<?php if (isset($_SESSION['email'])) { print($_SESSION['email']);}?>" OnClick="checkEMail(email);"/>
</div>
</td>
</tr>
<tr>
<td class="valigntop">
* Sujet   :
</td>
<td class="valigntop">
<div class="left">
<input type="radio" name="subject" value="Demande de contact" checked/> Demande de contact<br />
<input type="radio" name="subject"  value="Demande d\'information"/> Demande d'information<br />
<input type="radio" name="subject"  value="Suggestion d\'amélioration"/> Suggestion d'amélioration
</div>
</td>
</tr>
<tr>
<td class="valigntop">
Intervenant&nbsp;:
</td>
<td class="valigntop">
<div class="left">
<input type="text" name="intervenant" size="35" value= "<?php if (isset($_SESSION['intervenant'])) { print($_SESSION['intervenant']);}?>" OnClick="checkIntervenant(intervenant);"/>
</div>
</td>
</tr>
<tr>
<td class="valigntop">
* Message :
</td>
<td class="valigntop">
<div class="left">
<textarea rows="7" name="message" cols="50" maxlength="400" OnClick="checkMessage(message);"><?php if (isset($_SESSION['message'])) { print($_SESSION['message']);}?></textarea>
</textarea>
</div>
</td>
</tr>
<tr>
<td class="valigntop">
<br />
* Code :
</td>
<td class="valigntop">

<!-- Captcha Mathématique -->
<div class="center">
<div class="left" style="margin-left: 38%;">
Nombre aléatoire&nbsp;&nbsp;<span id="n1">&nbsp;</span><br />
Nombre aléatoire&nbsp;&nbsp;<span id="n2">&nbsp;</span><br />
Entrer la somme&nbsp;&nbsp;<input type="text" name="numcapt" size="3" OnClick="checkCaptchaMat(numcapt, resultat);"/>
<input type="hidden" id="re" name="resultat" size="5" />

<!-- On ne peut pas mettre l'appel du fichier javascript à la fin du fichier sinon la var resultat reste indéfinie -->
<!-- Script de création de la Captcha Mathématique  -->
<script src="js/contactcm.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">document.getElementById("re").value = resultat;</script>
</div>
</div>
<!-- Date en Php -->
<input type="hidden" name="dateforw" value= "<?php echo date("d/m/o H:i:s");?>" />
<br />
<br />
<input type="button" value="Annuler" OnBlur="form.reset();" />
<input type="submit" style="color: #00F;" value="Envoyer" />
<br />
<div class="left">
* : Champs obligatoires.
</div>
</td>
</tr>
</table>                                    
</form>
<p></p>
</td>
</tr>
</table>
<table class="center75">
<tr>
<td class="valigntop">
<div class="left">
<strong><em>Notre adresse</em></strong>
</div>

<div class="center2">
Association DogAnima<br/>
Château de la Villaine<br/>
La Faisanerie<br/>
37320 Esvres<p></p>
du Lundi 9h-16h au Vendredi 9h-16h30<br />
Samedi de 9h à 12h<br />
<p></p>
<img src="img/telephone.jpg" height="32" width="32" alt="Téléphone" title="Téléphone" />02 47 58 26 41<br/>
Fax  02 47 58 26 12
</div>
</tr>
</td>
</table>
<br />
<table class="center75">
<tr>
<td class="valigntopw63">
<div class="left">
<strong><em>Nous situer</em></strong>
</div>
<p></p>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10827.676108507967!2d0.7867439554216419!3d47.276837374758955!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47fcda96cbc579d1%3A0xd9d4041b4bc2e4b0!2sCh%C3%A2teau+De+La+Villaine!5e0!3m2!1sfr!2sfr!4v1447349740055" width="600" height="450" style="border: solid 1px #c0c0c0;border-radius: 8px;" allowfullscreen></iframe>
</td>
</tr>
</table>
<br />
</section>
<?php
   $_SESSION['errormsg']= "";
   session_destroy();
   session_write_close();
?>   
<?php include("inc/footer.inc.php"); ?>
</body>
</html>