<!DOCTYPE html>
<!--                            
    Projet DogAnima            
    pauline_b.php
    Création du 19/01/2015
	MAJ du 19/01/2015
	Rem : Un fichier print.css pour l'impression. 
--> 
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="index,nofollow" />
<title>DogAnima - Tarif de Pauline pour la garde à domicile ou en acceuil dans une famille - Pauline</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<?php include ("inc/header.inc.php"); ?>
<body>
<?php include_once("inc/analyticstracking.php") ?>
<div id="main">
<h1 class="title"><strong><em>Dog sitter à Manthelan 37</em></strong></h1>
</div>
<section>
<div class="left">
<div class="intv1">
<h2>Pauline, dog sitter à Manthelan 37</h2>
<p></p>
Possédant deux <strong>yorkshire terriers</strong>, Pauline peut accueillir votre compagnon chez elle pendant vos vacances.<br/>
Demeurant à <strong>Manthelan</strong> au sud de <strong>Saint-Branchs</strong> son tarif est de 15 euros par jour.
<p></p>
<p></p>
<div class="center">
<img src="img/Pauline-B.jpg" height="360" width="360" alt="Pauline dog sitter à Manthelan 37" title="Pauline dog sitter à Manthelan 37" />
</div>
</div>
</div>
<div class="intv1bis">
<h2>Une "mamie toutou"</h2>
<p>C'est ainsi qu'elle aime à se qualifier depuis qu'elle a décidé de se consacrer au bonheur de ses <strong>compagnons à quatre pattes</strong> et à ceux des autres. Le <strong>gardiennage de chiens</strong> est une seconde nature pour elle et vous serez surpris par l'accueil qu'elle réservera à votre animal dans sa grande propriété. Ses "<strong>hôtes canins</strong>" raffolent de ces grands espaces dans lesquels ils peuvent s'ébattre en toute sécurité.</p>
</div>
<div class="intv2">
<iframe src="https://www.google.com/maps/d/embed?mid=zRmiDXqgCE7s.kWCU2FZxQKOs" width="470" height="296"></iframe>
</div>
</section>
<table style="width: 100%;">
<tr>
<td>
<?php include("inc/footer.inc.php"); ?>
</td>
</tr>
</table>
</body>
</html>