<!DOCTYPE html>
<!--                            
    Projet DogAnima            
    nicolas_m.html                
    Création du 19/01/2015
	MAJ du 19/01/2015
--> 
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="robots" content="index,nofollow" />
<meta name="description" content="Nicolas garde votre chien chez lui à Saint-Branchs ou à votre domicile jusqu'à Tauxigny, Sorigny, Louans, Cormery, Esvres, Veigné, Ste-Catherine..."/>
<title>dog sitter (gardien de chiens) dans le secteur Saint-Branchs</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<?php include ("inc/headernico.inc.php"); ?>
<body>
<?php include_once("inc/analyticstracking.php") ?>
<div id="main">
<h1 class="title"><strong><em>Dog sitting à Saint-Branchs 37</em></strong></h1>
</div>
<section>
<div class="left">
<div class="intv1">
<h2>Nicolas, dog sitter à Saint-Branchs</h2>
<p><strong>Pet sitter</strong> depuis 5 ans, il peut garder votre chien <strong>en accueil</strong> chez lui ou <strong>à votre domicile</strong> pendant vos absences ou vos vacances. Demeurant à <strong>Saint-Branchs</strong>, au sud de Tours, son tarif est de 15 euros par jour.</p>
<div class="center">
<img src="img/Nicolas-M.jpg" height="360" width="360" alt="Nicolas dog sitter à Saint-Branchs 37" title="Nicolas dog sitter à Saint-Branchs 37" />
</div>
</div>
</div>
<div class="intv1bis">
<h2>Un gardien de chien expérimenté</h2>
<p>Nicolas a toujours eu des chiens dans sa famille. Du <strong>Saint-Bernard</strong> au <strong>caniche</strong>, il a appris à les observer et à s'en occuper. Il conduit fréquemment ses compagnons sur des <strong>parcours canins</strong> où ils peuvent se livrer à toutes sortes de jeux adaptés aux <strong>toutous</strong>. Si vous le souhaitez, lors de la garde de votre chien, Nicolas pourra l'amener s'amuser au <strong>Dog Center Park</strong> de <strong>Saint-Branchs</strong>.</p>
</div>
<div class="intv2">
<iframe src="https://www.google.com/maps/d/embed?mid=zRmiDXqgCE7s.kWCU2FZxQKOs" width="470" height="296"></iframe>
</div>
</section>
<table style="width: 100%;">
<tr>
<td>
<?php include("inc/footer.inc.php"); ?>
</td>
</tr>
</table>
</body>
</html>