<!DOCTYPE html>
<!--                            
    Projet DogAnima            
    viviane_g.php                
    Création du 19/01/2015
	MAJ du 19/01/2015
--> 
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire"/>
<meta name="robots" content="index,nofollow" />
<title>DogAnima - Tarifs pour la garde à domicile ou en acceuil dans une famille - Viviane</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<?php include("inc/header.inc.php"); ?>
<body>
<?php include_once("inc/analyticstracking.php") ?>
<div id="main">
<h1 class="title"><strong><em>Dog sitting à Esvres-sur-Indre 37</em></strong></h1>
</div>
<section>
<div class="left">
<div class="intv1">
<h2>Viviane, dog sitter à Esvres-sur-Indre 37</h2>
<p></p>
Possédant un <strong>épagneul</strong>, Viviane peut <strong>garder votre chien</strong> chez elle ou à votre domicile.<br/>
Demeurant à <strong>Esvres</strong> au <strong>sud de Tours</strong> son tarif est de 18 euros par jour.
<p></p>
<div class="center">
<img src="img/Viviane-G.jpg" height="360" width="360" alt="Viviane dog sitter à Esvres 37" title="Viviane Dog sitter à Esvres 37" />
</div>
</div>
<div class="intv1bis">
<h2>Une amoureuse des chiens</h2>
<p>La passion de Viviane pour les chiens est venue sur le tard, lorsqu'une amie lui a demandé un jour de garder son <strong>épagneul breton</strong> pendant les vacances. A son retour, Viviane enchantée par l'expérience a proposé à son amie de prendre un <strong>chiot</strong> d'une future <strong>portée</strong> et c'est ainsi qu'elle est entrée dans l'univers <strong>cynophile</strong>. Ce qu'elle apprécie tout particulièrement dans le <strong>dog sitting</strong> c'est de découvrir de nouvelles "personnalités <strong>canines</strong>".  </p>
</div>
<div class="intv2">
<iframe src="https://www.google.com/maps/d/embed?mid=zRmiDXqgCE7s.kWCU2FZxQKOs" width="470" height="296"></iframe>
</div>
</section>
<table style="width: 100%;">
<tr>
<td>
<?php include("inc/footer.inc.php"); ?>
</td>
</tr>
</table>
</body>
</html>