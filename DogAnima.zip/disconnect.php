<?php
   setcookie("firstname", -1);
   setcookie("BY", -1);
   header('Location: ./index.php');
?>