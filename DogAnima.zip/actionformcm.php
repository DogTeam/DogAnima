﻿<!DOCTYPE html>
<!--                            
    Projet DogAnima            
    actionformcm.php             
    Création 09/12/2015        
    MAJ du 20/01/2016
	MAJ du 02/05/2016
	MAJ du 07/05/2016
	MAJ du 09/05/2016
--> 
<html> 
<head>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<title>DogAnima - Contact</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<?php include ("inc/header.inc.php"); ?>
<div class="center">
<h1>
Merci de nous avoir contact&eacute;
</h1>

Message de contact envoyé le :
<?php 
   print($_POST["dateforw"]);
?>
<br />
Message de contact reçu le :
<?php
print(date("d/m/o H:i:s"));
?>
<br />
<br />
<?php
   session_start();
?>
<div class="justify">
<table class="center2">
<tr>
<td class="valigntop">
<b>Nom</b> :&nbsp; 
</td>
<td>
<?php 
    $lastnameOK = 0; 
    $_SESSION['lastname'] = $_POST["lastname"];
    if (!isset($_POST["lastname"]) || (is_numeric($_POST["lastname"])) || (empty($_POST["lastname"])) || (preg_match("/[0-9]/", $_POST["lastname"]))) {	
	   $_SESSION['errormsg'] = "*[Caractère(s) non valide(s) ou champ vide - Entrez le Nom !]";
	   header('location:contact.php#begin');
    } else {
		$lastnameOK = 1;
		print(mb_strtoupper($_POST["lastname"]));
    }		
?>	
</td>
</tr>
<tr>
<td class="valigntop">
<b>Prénom</b> :&nbsp;
</td>
<td>
<?php 
   $firstnameOK = 0;
   $_SESSION['firstname'] = $_POST["firstname"]; 
   if (!isset($_POST["firstname"]) || (is_numeric($_POST["firstname"])) || (empty($_POST["firstname"])) || (preg_match("/[0-9]/", $_POST["firstname"]))) {	
       $_SESSION['errormsg'] = "*[Caractère(s) non valide(s) ou champ vide - Entrez le Prénom !]";
	   header('location:contact.php#begin');
   } else {
	    $firstnameOK = 1;
		print($_POST["firstname"]);
   }
?>	
</td>
</tr>
<tr>
<td class="valigntop">
<b>Téléphone</b> :&nbsp;
</td>
<td>
<?php 
   $telOK = 0; 
   $_SESSION['tel'] = $_POST["tel"];
   if (!isset($_POST["tel"]) || (!is_numeric($_POST["tel"])) || (empty($_POST["tel"]))) {
	   $_SESSION['errormsg'] = "*[Caractère(s) non valide(s) ou champ vide - Entrez le Téléphone !]";
	   header('location:contact.php#begin'); 
   } else {
	    $telOK = 1; 
        print($_POST["tel"]); 	   
   }	   
?>
</td>
</tr>
<tr>
<td class="valigntop">
<b>e-mail</b> :&nbsp;
</td>
<td>
<?php 
   $emailOK = 0; 
   $_SESSION['email'] = $_POST["email"];
   $email = $_POST["email"]; 
   if (!isset($_POST["email"]) || (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) || (empty($_POST["email"]))) { 	   
       $_SESSION['errormsg'] = "*[Caractère(s) non valide(s) ou champ vide - Entrez l'email !]";
       header('location:contact.php#begin');
   } else {
	   $emailOK = 1; 
	   print($_POST["email"]);
   }	   
?>
</td>
</tr>
<tr>
<td class="valigntop">
<b>Sujet</b> :&nbsp;
</td>
<td class="valigntop">
<?php 
   $_SESSION['subject'] = $_POST["subject"];
   print(stripslashes($_POST["subject"]));  
   $subject = $_POST["subject"];
?>       
</td>
</tr>
<tr>
<td class="valigntop">					
<b>Intervenant</b>&nbsp;:&nbsp;
</td>
<td class="valigntop">
<?php 
   $_SESSION['intervenant'] = $_POST["intervenant"];
   print($_POST["intervenant"]);
?>
</td>
</tr>
<tr>
<td class="valigntop">					
<b>Message</b> :&nbsp; 
</td>
<td>
<div style="width: 460px; vertical-align: top; word-wrap: break-word;">
<?php 
   $messageOK = 0;
   $_SESSION["message"] = $_POST["message"];
   if ((strlen($_POST["message"]) == 0) || (preg_match("[/<>#{}/]", $_POST["message"]))) {
	  $_SESSION['errormsg'] = "*[Caractère(s) non valide(s) [<>#{}] ou champ vide - Entrez le Message !]"; 
      header('location:contact.php#begin');
   } else {   
       $messageOK = 1;
       print($_SESSION["message"]);
   }
   
   $message = $_POST["message"]; 
   
   // Test sur la Captcha mathématique 
   if ((intval($_POST["numcapt"])) != (intval($_POST["resultat"]))) {
	  $_SESSION['errormsg'] = "*[Caractère(s) non valide(s) ou champ vide - Entrez la somme des deux nombres !]"; 
      header('location:contact.php#begin'); 
   } 
?>   
</div>
</td>
</tr>
</table>

<?php 
if ($lastnameOK && $firstnameOK && $telOK && $emailOK && $messageOK) {
   include("inc/connect.inc.php"); 
   // $dbhost="localhost";
   // $dbuser="root";
   // $dbpassw=""; 
   // $dbname="doganima";  
  
   $message = addslashes($message);
   if ($id = mysqli_connect($dbhost, $dbuser, $dbpassw)){
      if (mysqli_select_db($id, $dbname)) {
         mysqli_query($id, "insert into msge(msge_subj, msge_txt, msge_ema) values ('$subject', '$message', '$email')");
	     mysqli_query($id, "commit");
	     mysqli_close($id); 
		 $_SESSION['firstname'] = "";
         $_SESSION['lastname'] = "";
         $_SESSION['tel'] = "";
         $_SESSION['email'] = "";
         $_SESSION['object'] = "";
         $_SESSION['intervenant'] = "";
         $_SESSION['message'] = "";
		 session_destroy();
		 session_write_close();
      } else {	 
           mysqli_close($id); 
		   $_SESSION['errormsg'] = "*[Erreur base de données  !]";
		   session_destroy();
		   session_write_close();
		   header("Location: ./contact.php"); 
      }
   } else {
	   mysqli_close($id); 
	   $_SESSION['errormsg'] = "*[Erreur base de données  !]";
	   session_destroy();
	   session_write_close();
       header("Location: ./contact.php"); 
   }
} else {
	$_SESSION['errormsg'] = "*[Erreur un champ est invalide  !]";
	session_destroy();
    session_write_close();
	header("Location: ./contact.php#begin"); 
}	

?>
<?php
   session_write_close();
?>
<br />
Redirection dans 20 secondes !
<br />	 
<br />	  
</div>
</div>

<br /><br />
<script src="js/actionform.js" type="text/javascript" charset="utf-8"></script>
<?php include("inc/footer.inc.php"); ?>
<!-- Redirection vers index.php dans 20 secondes ou au choix -->
<script type="text/javascript">reDirection('20');</script>
 </body>
</html>