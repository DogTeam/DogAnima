<!DOCTYPE html>
<!-- Projet DogAnima            
     indpage.php                
     Création 14/04/2016        
	 MAJ du 14/04/2016     
     MAJ du 22/04/2016	 
	 Auteur : Gouthière Laurent 
-->
<html>
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
-->
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
<meta name="description" content="Garde de chiens en famille d'accueil ou à domicile en Indre et Loire"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Garde de chiens à domicile ou en famille d'accueil</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<?php include ("inc/headermodifypage.inc.php"); ?>
<h1>
<?php 
    if (isset($_GET["virop"])) { 
	   $tp = $_GET["virop"];
       if ($tp != "22560fuc940") {
          header("Location: ./choice2.php?urdel=32250rop212");
	   }	  
	}
?>
</h1>
<p></p>

<?php
// Inclusion des constantes de connexion
include("inc/connect.inc.php");

// On va ici rechercher le texte de la page index.php enregistré dans la base de données
if ($id = mysqli_connect($dbhost, $dbuser, $dbpassw)){
  if (mysqli_select_db($id, $dbname)) { 
     mysqli_query($id, "SET NAMES 'utf8'");
	 $request = "select content_title, content_text1, content_text2, content_text3 from content where content_id >= content_id and trim(content_name) = 'index.php'";
	 if ($result = mysqli_query($id, $request)){
        while ($ligne = mysqli_fetch_row($result)){
		   $title = $ligne[0];
		   $text1 = $ligne[1];
		   $text21 = $ligne[2];
		   $text22 = $ligne[3];
		}		     		
		// mysqli_free_result($result);
	    mysqli_close($id);   	   
     } else {
          mysqli_close($id);    
          header("Location: ./choice2.php?urdel=32250rop212");	
     }		  
  } else {
       mysqli_close($id);     
	   header("Location: ./choice2.php?urdel=32250rop212");	
  }	   
} else {
     // mysqli_close($id);     
	 header("Location: ./choice2.php?urdel=32250rop212");	
}	 
?>

<!-- On procéde à l'affichage des différents champs en vue d'éventuellement les modifier -->
<form action="actionindpage.php" method="post" enctype="multipart/form-data" name="form">
<div class="index1">
<p></p>
<br />

<!-- Formulaire de visualisation puis de modification -->
<div class="center">
<input type="text" name="ititle" size="75" maxlength="110" value="<?php print($title); ?>">
</div>
<p></p>
<!-- Attention la limite à 400 a été vérifiée -->
<div class="center">
<textarea name="itext1" rows="6" cols="95" maxlength="410"><?php print($text1); ?></textarea>
</div>
<p></p>
<!-- Attention la limite à 910 a été vérifiée -->
<table style="width: 100%;">
<tr>
<td style="width: 49%;">
<textarea rows="19" name="itext21" cols="55" maxlength="1150"><?php print($text21); ?></textarea>
</td>
<td>&nbsp;</td>
<!-- Attention la limite à 910 a été vérifiée -->
<td style="width: 49%;">
<textarea rows="19" name="itext22" cols="55" maxlength="1150"><?php print($text22); ?></textarea>
</td>
</tr>
</table>
<br />
<div class="right">
<!-- Retrouver la page d'origine -->
<a href="indpagereinit.php?nicke=28129lim426"><input type="button" style="color: red; text-decoration: none;" value="Réinitialiser"></a>
&nbsp;
<!-- Sauvegarder la page modifiée -->
<input type="submit" style="color: #00F; text-decoration: none;" value="Modifier" />
&nbsp;
<!-- Retour au menu choice2 -->
<a href="choice2.php?urdel=32250rop212"><input type="button" style="color: red;" value="Quitter"></a>
&nbsp;
</div>
<br />
</div>
</form>
<p>&nbsp;</p>

<!-- Intégration du pied de page -->
<?php include("inc/footer.inc.php"); ?>
</body>
</html>