<!DOCTYPE html>
<!-- Projet DogAnima            
     connexion.php                
	 MAJ : 06/04/2016 
	 MAJ : 18/04/2016
-->
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width"/>
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="description" content="Garde de chiens en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Connexion</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body style="width: 960px;">
<?php include ("inc/headerdisconnect.inc.php"); ?>
<h1>Connection</h1>
<h3>Entrez le login et le mot de passe</h3>
<div style="text-align: center;" id="errormsg">&nbsp;</div>
<table style="width: 275px;">
<tr>
<td>
<form action="actionlogin.php" method="post" enctype="multipart/form-data" name="form" OnSubmit="return validateForm(this); autofocus">
<br />
<div class="center">
<div class="left">
&nbsp;* Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;<input type="text" id="idlogin" name="login" size="10" value="" OnClick="return checkLogin();" required />&nbsp;
</div>
<p></p>
<div class="left">
&nbsp;* Password&nbsp;&nbsp;:&nbsp;<input type="password" id="idpassword" name="password" size="10" value="" OnClick="return checkPassword();" />&nbsp;
</div>
<p></p>
<div class="right">
<input type="submit" name="submit" value="Envoyer"  />&nbsp;
</div>
</div>
</form>
</td>
</tr>
</table>
<?php 
    if (isset($_GET["gzhty"])) {
	   $tp = $_GET["gzhty"];	
       if ($tp == "268hz3622jo") {
	      print("<script>var bloc; document.getElementById('errormsg').style.color='red'; bloc = document.getElementById('errormsg');
         	    bloc.innerHTML = '*[Mot de passe ou login invalide !]';</script>");
       }	
	}
?>

<p></p>
<p></p>  
<?php include("inc/footer.inc.php"); ?>
<script src="js/connection.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>
 