<!DOCTYPE html>
<!-- Projet DogAnima            
     credits.html                 
     MAJ du 13/11/2015       
	 MAJ du 17/01/2015       
     Rem : Tout navigateur      
-->
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width"/>
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<!--
<meta name="keywords" content="DogAnima,Indre et Loire,tours,garde de chien,petsitting,famille d&#39;accueil,pension,chien"/>
-->
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Crédits</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<?php include ("inc/header.inc.php"); ?>
<div class="center">
<p></p>
<h1>Mini-projet:&nbsp;Emmanuel Leblanc et Laurent Gouthière CNAM 2015-2016&nbsp;
</h1>
<p></p>
<div class="justify">
<h2></h2>
</div>
<p></p>
<div class="center">
Copyright &copy; Laurent Gouthi&egrave;re et Emmanuel Leblanc
</div>
<p></p><br />
Enseignant: Philippe Bouquet
<p></p>
<br /><br />
</div>   
</section>	
<?php include("inc/footer.inc.php"); ?>
</body>
</html>
 