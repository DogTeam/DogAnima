<footer>
<div id="menufooter">
<br />
<a class="foot3" href="credits.php" title="Crédits">Crédits</a>
<a class="foot3" href="mentions-legales.php" title="Mentions légales">Mentions légales</a>
<a class="foot3" href="membres-equipe.php" title="Membres de l'équipe">Membres de l'équipe</a>
<a class="foot3" href="http://www.netpresta.fr" title="NetPresta Philippe Bouquet" target="_blank">NetPresta</a>
<br />
<p>
&nbsp;
</p>
</div>
</footer>