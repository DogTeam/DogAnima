<!DOCTYPE html>
<!-- Projet DogAnima            
     embres-equipe.php                 
     MAJ du 13/11/2015       
	 MAJ du 12/01/2015       
     Rem : Tout navigateur      
-->
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
<![endif]-->
<meta name="description" content="Garde de chien en accueil ou à domicile en Indre et Loire DogAnima"/>
<meta name="robots" content="noindex,nofollow" />
<title>DogAnima - Mentions légales</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<body>
<?php include ("inc/header.inc.php"); ?>
<p></p>
<h1>Membres de l'équipe</h1>
<div class="c9">
Laurent GOUTHIÈRE : Développeur<br />
Emmanuel LEBLANC : Développeur
</div>
<br /><br />
</div>
</div>
<br /><br /> 
</section>	
<?php include("inc/footer.inc.php"); ?>
</body>
</html>
 