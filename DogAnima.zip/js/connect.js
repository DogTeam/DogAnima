 function checkLogin() {
   var x = document.getElementById("login"); 
   var bloc;
   if ((x.value.match(/</)) || (x.value.length == 0)) {
	  document.getElementById('errormsg').style.color="red";
	  bloc = document.getElementById('errormsg');
	  bloc.innerHTML = "*[Entrez le login ou des caractères valides (pas <) !]";
	  document.getElementById("login").style.borderColor = "red";
	  x.focus();
      return false;
   } 
   document.getElementById("login").style.borderColor = "green";
   document.getElementById('errormsg').style.color="white";
   return true;
}	

function checkPassword() {
   var x = document.getElementById("myPsw");
   var bloc;
   if (x.value.length(x) >= 6)) {
	  document.getElementById('errormsg').style.color="white"; 
	  document.getElementById("myPsw").style.borderColor = "blue";
	  return true;
   } else {
	  document.getElementById('errormsg').style.color="red";
	  bloc = document.getElementById('errormsg');
	  bloc.innerHTML = "*[Entrez le password. Au moins 6 caractères !]";
	  document.getElementById("myPsw").style.borderColor = "red";
	  x.focus();
      return false;
   }	   
}	
	
function validateForm(form) {
   if (!checkLogin()) {
      return false;
   }
   if (!checkPassword()) {
	  return false; 
   }	
   document.getElementById('errormsg').style.color="#ececec";    
   return true;	
}	
