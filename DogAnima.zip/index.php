<!DOCTYPE html>
<!-- Projet DogAnima            
     index.php                 
     Création 13/11/2015       
	 MAJ du 24/03/2016  
	 MAJ du 14/04/2016  
	 MAJ du 20/04/2016  
	 MAJ du 24/04/2016
	 But: Charger la page index.php à partir de la base de données
-->
<html lang="fr">
<head>
<meta charset="utf-8" lang="fr" />
<meta name="viewport" content="width=device-width" />
<!--[if lt IE 9]>
<script src="http://github.com/aFarkas/html5shiv/blob/master/dist/html5shiv.js"></script>
-->
<meta name="description" content="Spécialisé dans le dog sitting (garde de chien) en Indre-et-Loire, nous vous proposons le plus grand réseau de dog sitters qualifiés du 37."/>
<meta name="google-site-verification" content="fuFAI0YJCKulvZ4LkiokEGmwNICxuNOg8rvHWn-4hKo" />
<meta name="robots" content="index,follow" />
<title>dog sitting (garde chien) au domicile ou en pension dans le 37</title>
<link rel="icon" type="img/x-ico" href="img/doganima.ico" />
<link href="css/styles.css" type="text/css" rel="stylesheet" media="screen" />
</head>
<?php include ("inc/headerindex.inc.php"); ?>
<body>
<?php include_once("inc/analyticstracking.php") ?>
<?php
include("inc/connect.inc.php");   

// <!-- Charge le texte de la page index.php à partir de la base de données -->
if ($id = mysqli_connect($dbhost, $dbuser, $dbpassw)){  //connexion au serveur
	mysqli_query($id, "SET NAMES 'utf8'");        //convertit texte utf8 vers ISO
    if (mysqli_select_db($id, $dbname)) {     //connexion au serveur
	 $request = "select content_title, content_text1, content_text2, content_text3 from content where content_id >= content_id and trim(content_name) = 'index.php'";
     if ($result = mysqli_query($id, $request)){    //Si requête non vide
        while ($ligne = mysqli_fetch_row($result)){           
		   $title = $ligne[0];
		   $text1 = $ligne[1];
		   $text2 = $ligne[2];
		   $text3 = $ligne[3];
		}		     		
		mysqli_free_result($result);      //Libère la mémoire de la requête
	    mysqli_close($id);   
     } else {
          mysqli_close($id);    
          header("Location: ./index.php");		
     }		  
  } else {
       mysqli_close($id);     
	   header("Location: ./index.php");		
  }	   
} else {
	 header("Location: ./index.php");		
}	 
?>
<h1 class="title"><strong><em><?php print($title); ?></em></strong></h1>
<section>
<p></p>
<!-- Affiche le titre, le texte des 3 blocs -->
<div class="ind1"><?php print($text1);?></div>
<p></p>
<div class="ind21"><?php print($text2);?></div>
<div class="ind22"><?php print($text3); ?></div>
<br />
<img src="img/dogan_2_x.jpg" height="190" width="945" alt="DogAnima" title="DogAnima" />
</section>
<?php include("inc/footer.inc.php"); ?>
</body>
</html>